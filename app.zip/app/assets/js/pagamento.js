$(document).ready(function() {

    $('#ncartao').mask('0000-0000-0000-0000');
    $('#cpf_cartao').mask('000.000.000-00');
    $('#codigo_seguranca').mask('000');
    $('#data_nascimento').mask('00/00/0000');
    $("#telefone").mask("(00) 0000-00009");

});